# Al Jawhara Turf Twin

Independent portfolio prototype: a real Three.js/WebGL stadium study and a local turf-inspection notebook inspired by Al Jawhara (Alinma Stadium), King Abdullah Sports City, Jeddah. This is not affiliated with the stadium, Ministry of Sport, Arup, FIFA, or a company project.

## Run locally

Requires Node.js 22+ and npm. From this directory:

```sh
npm ci
npm run dev
```

Open the URL printed by Vite. Do not open `index.html` directly from the filesystem; modules require HTTP.

```sh
npm run build
npm run preview
npm test
# Install Chrome separately if absent. The browser suite uses installed Google Chrome.
npx playwright install ffmpeg
TEST_URL=http://127.0.0.1:4173 npm run test:browser
```

The browser suite uses an isolated profile, captures screenshots and a video, and writes results under ignored `test-results/`. It never visits the published demo or uses real operational data.

## Walkthrough

1. Orbit the stadium; right-drag to pan; scroll or use the zoom buttons. Reset view restores the overview. Toggle the roof to examine the seating.
2. Choose Pitch inspection or Top-down. The roof is deliberately hidden for unobstructed inspection, and the camera eases into place.
3. Click a field zone or use the nine accessible zone buttons. A1–C3 have fixed local coordinates. The selected zone is outlined without a solid overlay covering grass.
4. Edit condition, visible wear, shade, notes and follow-up status. Save locally; switching zones also saves a pending draft. A saved edit changes its provenance from synthetic example to manual local entry.
5. Compare routine and enhanced inspection schedules before the assumed fixture horizon. Export a plain-text supervisor handover.
6. About this study explains sources, approximations and the four data categories.

## Scientific limits

Initial observations are synthetic. Local edits are manual notes, not instrument readings. No validated measurements, sensor feeds, sun-path model, turf-growth model, recovery percentage, safety decision or FIFA certificate is implemented. A visually clear zone is not necessarily safe. The rendered grass and lighting are illustrative and do not encode real observations.

Routine and enhanced schedules use assumed 24-hour and 12-hour intervals. Rounds = `max(0, ceil(hours / interval) - 1)`; visits = rounds × flagged zone count. The first round is one interval after now; only rounds strictly before kickoff count. This is workload exploration, not a validated recovery model. See `docs/RESEARCH.md`.

## Architecture

- `src/main.js`: semantic UI, selection state, editing and export orchestration.
- `src/data/demo.js`: synthetic records, stable zone definitions and enum values.
- `src/domain/scenarios.js`: pure review flags, transparent schedule comparison and handover text.
- `src/adapters/local.js`: validated, versioned local storage; failure falls back to session state.
- `src/scene/architecture.js`: instanced structural members and detailed plaza paving.
- `src/scene/stadium.js`: procedural stepped bowl, instanced seats, faceted roof and façade lattice.
- `src/scene/pitch.js`: deterministic procedural grass, markings, goals, raycast zones and labels.
- `src/scene/viewer.js`: renderer, lights, shadows, controls, camera transitions and failure handling.
- `tests/`: domain regression tests and actual Chrome interaction tests.
- `docs/legacy-demo.html`: exact original repository page retained for provenance; not shipped by Vite.

All runtime libraries and generated assets are bundled locally. No analytics, cookies, remote fonts, API keys or backend. External source links open only when clicked. The 3D scene uses a capped pixel ratio, shared geometry, an instanced seat mesh, and pauses rendering while the tab is hidden.

### Future integration boundaries

Replace the procedural stadium group with a licensed GLB after unit, origin, rotation and bounding-box checks; keep the pitch and camera contract stable. No asset is licensed merely because it appears in a marketplace.

Local pitch dimensions are a **105 × 68 m study assumption**, not verified stadium dimensions. Origin is the pitch centre; X runs along length, Z across width, Y up. A1–A3 occupy negative Z; C1–C3 positive Z. This is not a compass or georeferenced frame.

Future adapters should return records with stable IDs, observation timestamp, provenance, units, quality flags, calibration reference, sensor ID, and coordinate reference system. Real moisture, temperature, light, NDVI and maintenance histories need independent typed schemas and explicit source validation. Time-series storage and sensor APIs are intentionally not mocked. See `docs/DATA-CONTRACT.md`.

## Deployment

No deployment has been performed. See `docs/DEPLOYMENT.md` for an approval-gated GitHub Pages procedure. The `dist/` upload package is a static build with relative asset URLs, suitable for the repository's Pages subpath. Do not upload the source `index.html` as the deployment page.

## Known limitations

The architectural study is approximate, with 40 roof bays and approximately 15,000 seat instances used as visual sampling rather than an actual capacity model. It has no official CAD/BIM, structural validation, true façade fabrication pattern, concourse interiors or real site landscaping. Roof and exterior details remain simplified. Procedural seat placement is illustrative; seats use simplified seat-and-back geometry. Rendering is a lightweight realtime model, not photoreal visualization.

Camera bounds reduce underground/stand clipping but are not full collision detection; extreme manual orbit/zoom combinations may enter architecture. The automatic zone focus paths were tested for every zone. No sensor integration, longitudinal records, undo history, authentication, collaboration, encrypted storage or cloud backup is included. Local storage may be cleared by the browser. WebGL failure preserves form-based inspection; context loss requires reload. Mobile is usable but not a substitute for desktop visual inspection. One desktop Chrome environment was tested; no claim of cross-browser certification is made.

## Architectural presentation refinement

Presentation expands the stadium for interviews and hides the notebook temporarily. Exit presentation returns to inspection. Evening light toggles an illustrative studio-lighting setup; it is not a calibrated stadium lighting or sunlight model. Geometry now includes chair backs, recessed façade depth, solid diamond members, roof truss chords, hospitality mullions, plaza paving and bollards. Original Al Jawhara identity is retained; no Real Madrid branding or assets are used. This refinement does not claim the fidelity of an official architectural visualization.

Depth spacing between the pitch and its surrounding plane prevents overlapping-surface artifacts. Neither lighting mode is an exposure measurement.

## Supervisor / operations workspace

The redesigned page groups its controls around the supervisor's next action: review the summary, inspect a flagged zone, record a visual observation, compare follow-up workload and export a handover. The follow-up table is derived from the same records as the notebook and can show flagged or all zones; it is not a separate task database. Specialist-review records appear first. The sidebar links to actual page sections. See `docs/OPERATIONS-DESIGN.md` for layout decisions and design boundaries. Run `node tests/operations.mjs` against the production preview to reproduce the new workflow checks.

## Immersive operations simulator

The current interface opens a full-screen stadium stage with Explore Stadium, Inspect Pitch and Operations Review modes. See [experience notes](docs/IMMERSIVE-EXPERIENCE.md) for UX, architecture and limitations. Run `node tests/immersive.mjs` against the local preview on port 4173 for the current Chrome interaction suite; `TEST_URL` can override the URL. Older browser suites target the earlier dashboard layout.
