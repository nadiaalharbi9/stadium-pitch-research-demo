// End-to-end verification against installed desktop Chrome in an isolated test profile.
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const out='test-results';await fs.mkdir(out,{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true});
const ctx=await browser.newContext({viewport:{width:1440,height:1100},deviceScaleFactor:1,recordVideo:{dir:out+'/video',size:{width:1440,height:1100}}});
const page=await ctx.newPage(),errors=[],results=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const url=process.env.TEST_URL||'http://127.0.0.1:5173';
const settle=()=>page.waitForTimeout(1450);
const check=(name,detail)=>results.push({name,status:'passed',detail});
await page.goto(url);await settle();
let d=await page.evaluate(()=>window.__turfTwin.diagnostics());assert.ok(d.triangles>100000);assert.match(d.webgl,/WebGL 2/);check('real WebGL scene renders',d);
await page.screenshot({path:out+'/overview.png',fullPage:true});
await page.locator('#inspect').click();await settle();await page.screenshot({path:out+'/inspection.png',fullPage:true});
await page.locator('#top').click();await settle();await page.screenshot({path:out+'/top-down.png',fullPage:true});
// Use actual projected scene positions and pointer raycasting, not direct selection hooks.
for(const id of ['A1','A2','A3','B1','B2','B3','C1','C2','C3']){
 await page.locator('#top').click();await settle();
 const loc=await page.evaluate(id=>window.__turfTwin.projectZone(id),id);const bounds=await page.locator('#viewport').boundingBox();
 await page.mouse.click(bounds.x+loc.x,bounds.y+loc.y);await settle();
 assert.match(await page.locator('#zone-title').innerText(),new RegExp(id));
 d=await page.evaluate(()=>window.__turfTwin.diagnostics());const i='ABC'.indexOf(id[0]),j=Number(id[1])-1;
 assert.ok(Math.abs(d.target[0]-(j-1)*35)<.1&&Math.abs(d.target[2]-(i-1)*68/3)<.1);assert.ok(d.camera[1]>40);
}check('all nine scene zones raycast and focus correctly');
await page.screenshot({path:out+'/zone-c3.png',fullPage:true});
await page.locator('#notes').fill('Local test observation <script>plain text only</script>');await page.locator('#condition').selectOption('Visible wear');await page.locator('#wear').selectOption('Moderate');await page.locator('#status').selectOption('Reinspect');await page.locator('button[type=submit]').click();
await page.reload();await settle();await page.locator('[data-zone=C3]').click();await settle();assert.equal(await page.locator('#notes').inputValue(),'Local test observation <script>plain text only</script>');assert.equal(await page.locator('#review-count').innerText(),'4');check('edits persist across reload and safely render as text');
await page.locator('#notes').fill('Autosaved on zone switch');await page.locator('[data-zone=A1]').click();await page.locator('[data-zone=C3]').click();assert.equal(await page.locator('#notes').inputValue(),'Autosaved on zone switch');check('switching zones preserves drafts');
await page.locator('#hours').selectOption('24');assert.match(await page.locator('#routine').innerText(),/^0 rounds/);assert.match(await page.locator('#enhanced').innerText(),/^1 rounds · 4 zone visits/);
const downloadPromise=page.waitForEvent('download');await page.locator('#export').click();const download=await downloadPromise;await download.saveAs(out+'/sample-handover.txt');const exported=await fs.readFile(out+'/sample-handover.txt','utf8');assert.match(exported,/C3/);assert.match(exported,/No recovery forecast/);check('scenario changes and handover export');
await page.locator('#reset-data').click();await page.locator('#hours').selectOption('72');await page.locator('#reset-camera').click();await settle();
const before=await page.evaluate(()=>window.__turfTwin.diagnostics());const box=await page.locator('#viewport').boundingBox();
await page.mouse.move(box.x+box.width*.4,box.y+box.height*.7);await page.mouse.down();await page.mouse.move(box.x+box.width*.6,box.y+box.height*.7,{steps:15});await page.mouse.up();await settle();const after=await page.evaluate(()=>window.__turfTwin.diagnostics());assert.ok(Math.abs(after.camera[0]-before.camera[0])>5);check('mouse orbit changes camera');
await page.mouse.move(box.x+box.width*.5,box.y+box.height*.65);await page.mouse.down({button:'right'});await page.mouse.move(box.x+box.width*.55,box.y+box.height*.65,{steps:10});await page.mouse.up({button:'right'});await settle();const pan=await page.evaluate(()=>window.__turfTwin.diagnostics());assert.ok(Math.abs(pan.target[0])+Math.abs(pan.target[2])>1);check('right-drag pan changes target');
await page.locator('#zoom-in').click();const zoom=await page.evaluate(()=>window.__turfTwin.diagnostics());assert.notDeepEqual(zoom.camera,pan.camera);await page.locator('#reset-camera').click();await settle();d=await page.evaluate(()=>window.__turfTwin.diagnostics());assert.ok(Math.abs(d.camera[0]-170)<.1);check('zoom and reset camera');
await page.locator('#about').click();assert.ok(await page.locator('#about-dialog').isVisible());await page.keyboard.press('Escape');assert.ok(!await page.locator('#about-dialog').isVisible());check('research dialog and keyboard dismissal');
await page.locator('[data-zone=A3]').focus();await page.keyboard.press('Enter');await settle();assert.match(await page.locator('#zone-title').innerText(),/A3/);check('keyboard zone selection');
await page.locator('#reset-camera').click();await settle();
const samples=[];for(let i=0;i<5;i++){await page.waitForTimeout(1000);samples.push((await page.evaluate(()=>window.__turfTwin.diagnostics())).fps);}check('desktop performance sample',{fps:samples,browser:browser.version(),viewport:'1440 × 1100 / DPR 1'});
for(const [width,height] of [[1280,800],[1024,768],[390,844]]){await page.setViewportSize({width,height});await page.locator('#reset-camera').click();await settle();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:`${out}/responsive-${width}.png`,fullPage:true});}check('responsive widths 1280, 1024 and 390 have no horizontal overflow');
assert.deepEqual(errors,[]);check('no JavaScript runtime or console errors in normal workflow');
// Denied storage and unavailable WebGL use separate fresh contexts.
const denied=await browser.newContext();await denied.addInitScript(()=>Object.defineProperty(window,'localStorage',{get(){throw new Error('Storage denied test');}}));const dp=await denied.newPage();await dp.goto(url);await dp.locator('#notes').fill('Session-only test');await dp.locator('button[type=submit]').click();assert.match(await dp.locator('#save-status').innerText(),/session only/);await denied.close();check('storage denial preserves session-only editing');
const fallback=await browser.newContext({viewport:{width:1280,height:900}});await fallback.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(type,...args){return /webgl/i.test(type)?null:original.call(this,type,...args);};});const fp=await fallback.newPage();await fp.goto(url);assert.ok(await fp.locator('#fallback').isVisible());await fp.locator('[data-zone=A1]').click();await fp.locator('#notes').fill('Fallback entry');await fp.locator('button[type=submit]').click();assert.match(await fp.locator('#save-status').innerText(),/Saved/);await fp.screenshot({path:out+'/webgl-fallback.png',fullPage:true});await fallback.close();check('WebGL initialization failure leaves notebook functional');
await ctx.close();await browser.close();await fs.writeFile(out+'/browser-results.json',JSON.stringify({results,errors},null,2));console.log(JSON.stringify({passed:results.length,errors,results},null,2));
