import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const out='test-results/immersive';await fs.mkdir(out,{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true});
const ctx=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1});
const p=await ctx.newPage(),errors=[],checks=[];
p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const url=process.env.TEST_URL||'http://127.0.0.1:4173';const settle=()=>p.waitForTimeout(1850);const pass=name=>{checks.push(name);console.log('PASS '+name);};
const diag=()=>p.evaluate(()=>window.__turfTwin.diagnostics());
try{
await p.goto(url);await settle();assert.match((await diag()).webgl,/WebGL 2/);assert.ok((await diag()).triangles>100000);assert.equal(await p.locator('.inspector').isVisible(),false);assert.equal((await p.locator('#viewport').boundingBox()).height,960);pass('Full-screen WebGL exploration, no notebook or dashboard');
await p.screenshot({path:out+'/explore.png'});
let before=await diag();await p.mouse.move(800,650);await p.mouse.down();await p.mouse.move(950,630,{steps:12});await p.mouse.up();await settle();assert.notDeepEqual((await diag()).camera,before.camera);pass('Orbit gesture');
before=await diag();await p.mouse.move(850,650);await p.mouse.down({button:'right'});await p.mouse.move(930,650,{steps:10});await p.mouse.up({button:'right'});await settle();assert.notDeepEqual((await diag()).target,before.target);pass('Pan gesture');
before=await diag();await p.locator('#zoom-in').click();assert.notDeepEqual((await diag()).camera,before.camera);await p.locator('#reset-camera').click();await settle();assert.ok(Math.abs((await diag()).camera[0]-225)<.1);pass('Zoom and overview reset');
await p.locator('#roof').click();assert.equal(await p.locator('#roof').getAttribute('aria-pressed'),'false');await p.locator('#roof').click();await p.locator('#lighting').click();await settle();await p.screenshot({path:out+'/evening.png'});await p.locator('#lighting').click();pass('Roof visibility and illustrative evening lighting');
await p.locator('#enter-inspection').click();await settle();assert.equal(await p.locator('.inspector').isVisible(),true);assert.equal((await diag()).mode,'inspect');await p.screenshot({path:out+'/inspect.png'});pass('Inspect mode opens notebook and camera transition');
for(const id of ['A1','A2','A3','B1','B2','B3','C1','C2','C3']){
 await p.locator('#pitch-top').click();await settle();
 const loc=await p.evaluate(id=>window.__turfTwin.projectZone(id),id);const box=await p.locator('#viewport').boundingBox();
 await p.mouse.click(box.x+loc.x,box.y+loc.y);await settle();
 assert.match(await p.locator('#zone-title').innerText(),new RegExp(id));const d=await diag();assert.ok(Math.abs(d.target[0]-(Number(id[1])-2)*35)<.1);assert.ok(Math.abs(d.target[2]-('ABC'.indexOf(id[0])-1)*68/3)<.1);
}pass('All nine actual turf raycasts and exact zone camera targets');
await p.screenshot({path:out+'/zone-focus.png'});
await p.locator('#notes').fill('Synthetic test: inspect worn area <script>plain text</script>');await p.locator('#condition').selectOption('Visible wear');await p.locator('#status').selectOption('Reinspect');await p.locator('button[type=submit]').click();await p.reload();await settle();await p.locator('#mode-inspect').click();await p.locator('[data-zone=C3]').click();assert.equal(await p.locator('#notes').inputValue(),'Synthetic test: inspect worn area <script>plain text</script>');pass('Local persistence and safe note rendering');
await p.locator('#notes').fill('Auto-save on operations review');await p.locator('#mode-review').click();assert.equal(await p.locator('#operations-review').isVisible(),true);assert.equal(await p.locator('.inspector').isVisible(),false);assert.ok((await p.locator('#manual-count').innerText())==='1');await p.locator('#queue-all').click();assert.equal(await p.locator('#queue-body tr').count(),9);await p.locator('#queue-review').click();pass('Review mode, autosave, and queue filters');
await p.locator('#hours').selectOption('48');assert.equal(await p.locator('#fixture-metric').innerText(),'48h');await p.locator('#export').scrollIntoViewIfNeeded();const dl=p.waitForEvent('download');await p.locator('#export').click();await (await dl).saveAs(out+'/handover.txt');assert.match(await fs.readFile(out+'/handover.txt','utf8'),/Auto-save on operations review/);pass('Fixture assumption and handover download');
await p.locator('#operations-review').evaluate(e=>e.scrollTop=0);await p.screenshot({path:out+'/review.png'});
await p.getByRole('button',{name:'Inspect queue zone C2',exact:true}).click();await settle();assert.equal((await diag()).selected,'C2');assert.equal(await p.locator('#operations-review').isVisible(),false);pass('Queue action returns to correct pitch zone');
await p.locator('#close-inspector').click();assert.equal(await p.locator('.inspector').isVisible(),false);await p.locator('#open-inspector').click();assert.equal(await p.locator('.inspector').isVisible(),true);pass('Notebook collapse and reopen');
await p.locator('[data-zone=A3]').focus();await p.keyboard.press('Enter');await settle();assert.equal((await diag()).selected,'A3');pass('Keyboard zone selection');
await p.locator('#reset-data').click();await p.locator('#mode-explore').click();await settle();await p.locator('#presentation').click();assert.equal(await p.locator('.scene-intro').isVisible(),false);await p.locator('#presentation').click();await p.locator('#about').click();assert.ok(await p.locator('#about-dialog').isVisible());await p.keyboard.press('Escape');pass('HUD toggle and research dialog');
const fps=[];for(let i=0;i<3;i++){await p.waitForTimeout(1100);fps.push((await diag()).fps);}checks.push({performanceSamples:fps});
for(const size of [{width:1280,height:800},{width:390,height:844}]){
 await p.setViewportSize(size);await p.locator('#mode-explore').click();await settle();assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await p.screenshot({path:out+`/explore-${size.width}.png`});
 await p.locator('#mode-inspect').click();await settle();assert.ok(await p.locator('#zone-grid').isVisible());await p.screenshot({path:out+`/inspect-${size.width}.png`});
 await p.locator('#mode-review').click();assert.ok(await p.locator('#operations-review').isVisible());assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await p.screenshot({path:out+`/review-${size.width}.png`});
}pass('1280 desktop and 390 mobile all three modes without horizontal overflow');
assert.deepEqual(errors,[]);pass('No runtime or console errors');
const fallback=await ctx.newPage();await fallback.addInitScript(()=>{const orig=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(type,...args){return type.includes('webgl')?null:orig.call(this,type,...args);};});await fallback.goto(url);assert.ok(await fallback.locator('#fallback').isVisible());await fallback.locator('#mode-inspect').click();await fallback.locator('[data-zone=A1]').click();await fallback.locator('#notes').fill('Fallback local note');await fallback.locator('button[type=submit]').click();assert.match(await fallback.locator('#save-status').innerText(),/Saved/);await fallback.screenshot({path:out+'/webgl-fallback.png'});await fallback.close();pass('WebGL failure leaves manual notebook usable');
await fs.writeFile(out+'/results.json',JSON.stringify({checks,errors},null,2));
} finally {await browser.close();}
