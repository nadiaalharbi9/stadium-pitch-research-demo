// The shell only coordinates presentation. Observation and scene state stay in their modules.
export function mountImmersiveShell({onExplore,onInspect,onReview}) {
 const $=id=>document.getElementById(id);
 document.body.classList.add('immersive');
 document.body.dataset.experience='explore';
 const header=document.querySelector('.header');
 const about=$('about'),presentation=$('presentation');
 header.replaceChildren();
 header.innerHTML=`<a class="sim-brand" href="./" aria-label="Jawhara home"><span class="sim-symbol">◇</span><span>JAWHARA<small>TURF TWIN / OPERATIONS STUDY</small></span></a><nav class="experience-modes" aria-label="Experience modes"><button id="mode-explore"><span>01</span> Explore Stadium</button><button id="mode-inspect"><span>02</span> Inspect Pitch</button><button id="mode-review"><span>03</span> Operations Review</button></nav><div class="sim-header-tools"><span class="study-status"><i></i> LOCAL STUDY</span></div>`;
 header.querySelector('.sim-header-tools').append(about,presentation);
 presentation.textContent='Hide HUD';
 const stage=document.querySelector('.viewport-wrap');
 document.querySelector('#app').append(stage);
 stage.setAttribute('aria-label','Stadium simulation stage');
 const inspector=document.querySelector('.inspector');
 document.querySelector('#app').append(inspector);
 inspector.id='inspection-panel';inspector.setAttribute('aria-label','Zone inspection notebook');
 inspector.querySelector('.panel-heading').insertAdjacentHTML('beforeend','<button id="close-inspector" class="icon-button" aria-label="Collapse inspection notebook">−</button>');
 const review=document.createElement('section');review.id='operations-review';review.setAttribute('aria-label','Operations review');
 review.innerHTML=`<div class="review-heading"><div><span class="eyebrow">03 / OPERATIONS REVIEW</span><h1>From observation<br>to next action.</h1><p>Review local records, plan follow-up, and prepare the handover.</p></div><button id="back-to-pitch">Return to pitch ↗</button></div>`;
 review.append(document.querySelector('.metrics'),$('follow-up'),$('planning'));
 document.querySelector('#app').append(review);
 const hud=document.createElement('div');hud.className='immersive-hud';
 hud.innerHTML=`<div class="scene-intro"><div class="location-label"><span></span> JEDDAH, SAUDI ARABIA</div><h1>The stadium.<br><em>The surface.</em><br>The next move.</h1><p>An Al Jawhara-inspired environment.<br>A closer view of the pitch.</p><button id="enter-inspection" class="primary">Begin pitch inspection <span>↗</span></button></div><div class="inspection-caption"><span class="eyebrow">02 / FIELD INSPECTION</span><h1>Read the surface.</h1><p>Choose a zone. Record an observation. Set a follow-up.</p></div><div class="inspection-toolbar"><button id="pitch-wide">Pitch view</button><button id="pitch-top">Top-down</button><button id="open-inspector" aria-controls="inspection-panel">Zone notebook ↗</button></div><div class="stage-footer"><span><i></i> INDEPENDENT PROTOTYPE <b>/</b> Synthetic examples + manual local entries</span><span>Approximate architecture · No live stadium connection</span></div><div class="stage-index"><span>AL JAWHARA</span><strong>01 / EXPLORE</strong><small>STYLIZED ARCHITECTURAL STUDY</small></div>`;
 document.querySelector('#app').append(hud);
 document.querySelector('.scene-title').hidden=true;
 document.querySelector('.scene-tag').hidden=true;
 // Remove the old dashboard shell after retaining its functional workspaces.
 document.querySelector('.app-nav').hidden=true;
 document.querySelector('.dashboard-heading').hidden=true;
 document.querySelector('main').hidden=true;
 document.querySelector('footer').hidden=true;
 const activate=mode=>{
  const previous=document.body.dataset.experience;
  document.body.dataset.experience=mode;
  if(previous!==mode){inspector.scrollTop=0;review.scrollTop=0;}
  review.hidden=mode!=='review';inspector.hidden=mode!=='inspect';
  if(mode==='inspect')document.body.classList.remove('notebook-collapsed');
  for(const name of ['explore','inspect','review']){const b=$('mode-'+name);b.classList.toggle('active',name===mode);b.setAttribute('aria-pressed',String(name===mode));}
  document.querySelector('.stage-index strong').textContent=mode==='explore'?'01 / EXPLORE':mode==='inspect'?'02 / INSPECT':'03 / REVIEW';
 };
 $('mode-explore').onclick=onExplore;
 $('mode-inspect').onclick=onInspect;
 $('enter-inspection').onclick=onInspect;
 $('mode-review').onclick=()=>{onReview();activate('review');};
 $('back-to-pitch').onclick=onInspect;
 $('pitch-wide').onclick=onInspect;
 $('pitch-top').onclick=()=>$('top').click();
 $('close-inspector').onclick=()=>{document.body.classList.add('notebook-collapsed');$('open-inspector').focus();};
 $('open-inspector').onclick=()=>document.body.classList.remove('notebook-collapsed');
 activate('explore');
 return {activate};
}
