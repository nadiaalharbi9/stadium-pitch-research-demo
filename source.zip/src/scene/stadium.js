import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {beamInstances} from './architecture.js';
const TAU=Math.PI*2;
export function bowlPoint(a,rx,rz,y,p=2.5){return new T.Vector3(rx*Math.sign(Math.cos(a))*Math.abs(Math.cos(a))**(2/p),y,rz*Math.sign(Math.sin(a))*Math.abs(Math.sin(a))**(2/p));}
function mesh(positions,mat){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.computeVertexNormals();return new T.Mesh(g,mat);}
function quad(out,a,b,c,d){out.push(...a,...b,...c,...a,...c,...d);}
export function buildStadium(){
 const group=new T.Group(),roof=new T.Group();group.add(roof);
 const concrete=new T.MeshStandardMaterial({color:0x656f73,roughness:.86,side:T.DoubleSide});
 const shell=new T.MeshStandardMaterial({color:0xc6c9c4,roughness:.72,metalness:.08,side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:1,polygonOffsetUnits:1});
 const steel=new T.LineBasicMaterial({color:0xb7bfb7});
 const dark=new T.MeshStandardMaterial({color:0x233439,roughness:.75,side:T.DoubleSide});
 const tierData=[{rows:16,rx:63,rz:43,y:1,step:1.02,rise:.62},{rows:9,rx:81,rz:61,y:13,step:1,rise:.7},{rows:15,rx:93,rz:73,y:22,step:.91,rise:.7}];
 const seatMatrices=[],seatColors=[],obj=new T.Object3D();
 const palette=[0xd9d9c9,0xbec6bb,0xc2a15b,0xd4b566,0xe1e0d5];
 const steps=[];
 for(const [ti,t] of tierData.entries())for(let r=0;r<t.rows;r++){
  const rx=t.rx+r*t.step,rz=t.rz+r*t.step,y=t.y+r*t.rise;
  for(let j=0;j<192;j++){const a=j/192*TAU,b=(j+1)/192*TAU;
   quad(steps,bowlPoint(a,rx,rz,y).toArray(),bowlPoint(b,rx,rz,y).toArray(),bowlPoint(b,rx+t.step,rz+t.step,y).toArray(),bowlPoint(a,rx+t.step,rz+t.step,y).toArray());
   quad(steps,bowlPoint(a,rx+t.step,rz+t.step,y).toArray(),bowlPoint(b,rx+t.step,rz+t.step,y).toArray(),bowlPoint(b,rx+t.step,rz+t.step,y+t.rise).toArray(),bowlPoint(a,rx+t.step,rz+t.step,y+t.rise).toArray());
  }
  const count=Math.floor((rx+rz)*Math.PI/1.05);
  for(let j=0;j<count;j++){
   const a=j/count*TAU,sector=(a/TAU*32)%1;if(sector<.065||sector>.935)continue;
   // Vomitories interrupt selected rows rather than forming continuous walls.
   if(r<4&&ti>0&&Math.floor(a/TAU*32)%4===0&&sector>.32&&sector<.68)continue;
   const v=bowlPoint(a,rx+.45,rz+.45,y+.35);obj.position.copy(v);obj.rotation.y=Math.atan2(-v.x,-v.z);obj.updateMatrix();seatMatrices.push(obj.matrix.clone());seatColors.push(palette[(Math.floor(a/TAU*32)+Math.floor(r/4)+ti)%5]);
  }
 }
 const terraces=mesh(steps,concrete);terraces.receiveShadow=true;group.add(terraces);
 const seatBase=new T.BoxGeometry(.64,.12,.58);const seatBack=new T.BoxGeometry(.64,.49,.10);seatBack.translate(0,.23,-.25);const seatGeometry=mergeGeometries([seatBase,seatBack]);
 const seats=new T.InstancedMesh(seatGeometry,new T.MeshStandardMaterial({roughness:.73}),seatMatrices.length);
 seatMatrices.forEach((m,i)=>{seats.setMatrixAt(i,m);seats.setColorAt(i,new T.Color(seatColors[i]));});group.add(seats);
 // Dark hospitality ribbons separate the three bowl tiers.
 for(const [rx,rz,y,h] of [[80,60,11,2],[92,72,19,3]]){
  const p=[];for(let i=0;i<192;i++){const a=i/192*TAU,b=(i+1)/192*TAU;quad(p,bowlPoint(a,rx,rz,y).toArray(),bowlPoint(b,rx,rz,y).toArray(),bowlPoint(b,rx,rz,y+h).toArray(),bowlPoint(a,rx,rz,y+h).toArray());}group.add(mesh(p,dark));
 }
 const roofPositions=[],roofLines=[],facadeLines=[],ribs=[],lattice=[];const segments=40;
 const line=(out,a,b)=>out.push(...a.toArray(),...b.toArray());
 for(let i=0;i<segments;i++){
  const a=i/segments*TAU,b=(i+1)/segments*TAU,m=(a+b)/2;
  const oa=bowlPoint(a,113,94,32,2.2),ob=bowlPoint(b,113,94,32,2.2),peak=bowlPoint(m,104,85,36.8,2.2);
  const ia=bowlPoint(a,73,51,35,2.2),ib=bowlPoint(b,73,51,35,2.2);
  for(const tri of [[oa,ob,peak],[oa,peak,ia],[peak,ib,ia],[peak,ob,ib]])roofPositions.push(...tri.flatMap(v=>v.toArray()));
  for(const [v,w] of [[oa,ob],[oa,peak],[ob,peak],[ia,peak],[ib,peak],[ia,ib],[oa,ia]])line(roofLines,v,w);
  const low=bowlPoint(m,109,90,5,2.2);ribs.push([oa,low],[low,ob]);
  // Nested open diamonds echo mashrabiya without using protected texture assets.
  for(let k=0;k<5;k++)for(let l=0;l<3;l++){
   const aa=a+(b-a)*(k+.5)/5,cy=10+l*6,da=(b-a)/12;
   const vs=[bowlPoint(aa,111,92,cy+3,2.2),bowlPoint(aa+da,111,92,cy,2.2),bowlPoint(aa,111,92,cy-3,2.2),bowlPoint(aa-da,111,92,cy,2.2)];
   for(let n=0;n<4;n++)lattice.push([vs[n],vs[(n+1)%4]]);
  }
  const under=peak.clone();under.y-=3;
  line(roofLines,oa,under);line(roofLines,under,ia);line(roofLines,under,peak);
 }
 const roofMesh=mesh(roofPositions,shell);roofMesh.castShadow=true;roofMesh.receiveShadow=false;roof.add(roofMesh);
 const lines=(p,mat)=>new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(p,3)),mat);
 roof.add(lines(roofLines,steel));group.add(lines(facadeLines,steel));
 const champagne=new T.MeshStandardMaterial({color:0xbcb6a1,roughness:.42,metalness:.55});
 group.add(beamInstances(ribs,.44,champagne),beamInstances(lattice,.085,champagne));
 // Recessed exterior behind the open lattice creates architectural depth.
 const facade=[];for(let j=0;j<160;j++){const a=j/160*TAU,b=(j+1)/160*TAU;quad(facade,bowlPoint(a,108,89,4,2.2).toArray(),bowlPoint(b,108,89,4,2.2).toArray(),bowlPoint(b,110,91,30,2.2).toArray(),bowlPoint(a,110,91,30,2.2).toArray());}
 group.add(mesh(facade,new T.MeshStandardMaterial({color:0x273a3d,metalness:.25,roughness:.7,side:T.DoubleSide})));
 const band=[];for(let j=0;j<160;j++){const a=j/160*TAU,b=(j+1)/160*TAU;quad(band,bowlPoint(a,112,93,2,2.2).toArray(),bowlPoint(b,112,93,2,2.2).toArray(),bowlPoint(b,112,93,4,2.2).toArray(),bowlPoint(a,112,93,4,2.2).toArray());}group.add(mesh(band,concrete));
 // Structural chords below the membrane, visible when orbiting beneath the roof edge.
 const trusses=[];for(let j=0;j<40;j++){const a=j/40*TAU;for(let k=0;k<8;k++){const t=k/8,u=(k+1)/8;const top=bowlPoint(a,113-40*t,94-43*t,32+3*t,2.2),next=bowlPoint(a,113-40*u,94-43*u,32+3*u,2.2);const bottom=top.clone();bottom.y-=2.4;const nextBottom=next.clone();nextBottom.y-=2.4;trusses.push([top,bottom],[bottom,next],[bottom,nextBottom]);}}roof.add(beamInstances(trusses,.11,champagne));
 // Hospitality mullions, upper edge railings, and a warm concourse ribbon.
 const railPairs=[];for(const [rx,rz,y] of [[80,60,13],[92,72,22]])for(let j=0;j<160;j++){const a=j/160*TAU,b=(j+1)/160*TAU;railPairs.push([bowlPoint(a,rx,rz,y),bowlPoint(b,rx,rz,y)],[bowlPoint(a,rx,rz,y-1.7),bowlPoint(a,rx,rz,y)]);}group.add(beamInstances(railPairs,.06,champagne));

 const base=new T.Mesh(new T.CylinderGeometry(1,1,3,96),new T.MeshStandardMaterial({color:0x68746e,roughness:1}));base.scale.set(117,1,98);base.position.y=-2;group.add(base);
 return {group,roof,seatCount:seatMatrices.length};
}
