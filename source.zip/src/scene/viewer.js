import * as T from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {buildStadium} from './stadium.js';
import {buildPitch} from './pitch.js';
import {makePlaza} from './architecture.js';
import {zoneDefinitions} from '../data/demo.js';
export function createViewer(host,onSelect,onError){
 const renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setClearColor(0x0b1521,1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
 host.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-label','Interactive 3D stadium. Drag to orbit, right-drag to pan, scroll to zoom. Use zone buttons for keyboard inspection.');
 const scene=new T.Scene();const pmrem=new T.PMREMGenerator(renderer);const room=new RoomEnvironment();const environment=pmrem.fromScene(room,.04);scene.environment=environment.texture;scene.environmentIntensity=.35;room.dispose();pmrem.dispose();scene.fog=new T.Fog(0x0b1521,280,650);
 const camera=new T.PerspectiveCamera(42,1,1,1200);camera.position.set(225,195,260);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.09;controls.minDistance=22;controls.maxDistance=460;controls.maxPolarAngle=Math.PI*.43;controls.target.set(0,5,0);controls.update();
 const ambient=new T.HemisphereLight(0xcce1e5,0x313b35,1.5);scene.add(ambient);
 const sun=new T.DirectionalLight(0xffebcd,2.6);sun.position.set(-130,130,60);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-145,right:145,top:145,bottom:-145,near:1,far:440});sun.shadow.bias=-.001;sun.shadow.normalBias=.35;scene.add(sun);
 const fill=new T.DirectionalLight(0xc1dfef,.8);fill.position.set(100,100,-70);scene.add(fill);
 const stadium=buildStadium(),pitch=buildPitch();scene.add(stadium.group,pitch.group);
 const ground=new T.Mesh(new T.PlaneGeometry(1500,1500),new T.MeshStandardMaterial({color:0x0c1723,roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.y=-3.6;ground.receiveShadow=true;scene.add(ground);
 scene.add(makePlaza());
 const floodlights=[];for(const x of [-45,0,45])for(const z of [-42,42]){const lamp=new T.SpotLight(0xe2f1ff,0,180,.55,.7,1);lamp.position.set(x,34,z);lamp.target.position.set(x*.5,0,0);scene.add(lamp,lamp.target);floodlights.push(lamp);}
 function setLighting(evening){scene.environmentIntensity=evening?.12:.35;renderer.setClearColor(evening?0x08131c:0x0b1521,1);ambient.intensity=evening?.32:1.5;sun.intensity=evening?.35:2.6;fill.intensity=evening?.55:.8;renderer.toneMappingExposure=evening?1.18:1.05;floodlights.forEach(l=>l.intensity=evening?25:0);}

 let presentation=false;
 let mode='overview',selected='B2',transition=null,roofEnabled=true,frames=0,last=performance.now(),fps=0;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 function move(pos,target){const fit=Math.max(1,1.3/(host.clientWidth/host.clientHeight));pos=pos.map((v,i)=>target[i]+(v-target[i])*fit);transition={start:performance.now(),from:camera.position.clone(),to:new T.Vector3(...pos),oldTarget:controls.target.clone(),target:new T.Vector3(...target)};if(reduced)transition.start-=1800;}
 function setMode(next){mode=next;stadium.roof.visible=roofEnabled&&mode==='overview';pitch.select(selected,mode!=='overview');
  if(next==='overview')move([225,195,260],[0,5,0]);
  else if(next==='top')move([0,155,.01],[0,0,0]);
  else if(next==='inspect')move([8,130,85],[0,0,0]);
 }
 function select(id,focus=true){selected=id;pitch.select(id,true);if(focus){mode='focus';stadium.roof.visible=false;const z=zoneDefinitions.find(z=>z.id===id);move([z.x+4,48,z.z+30],[z.x,0,z.z]);}}
 controls.addEventListener('start',()=>{transition=null;});
 const ray=new T.Raycaster(),pointer=new T.Vector2();let down=null;
 renderer.domElement.addEventListener('pointerdown',e=>down={x:e.clientX,y:e.clientY});
 renderer.domElement.addEventListener('pointerup',e=>{if(mode==='overview'||!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>5)return;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);const hits=ray.intersectObjects(pitch.hitTargets);if(hits.length)onSelect(hits[0].object.userData.zone);});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();renderer.setAnimationLoop(null);onError('The 3D graphics context was interrupted. Reload to restore it. Zone inspection remains available.');});
 renderer.setAnimationLoop(()=>{if(document.hidden)return;const now=performance.now();
  if(transition){const t=Math.min(1,(now-transition.start)/1650),ease=t*t*t*(t*(t*6-15)+10);camera.position.lerpVectors(transition.from,transition.to,ease);controls.target.lerpVectors(transition.oldTarget,transition.target,ease);if(t===1)transition=null;}
  controls.target.x=T.MathUtils.clamp(controls.target.x,-80,80);controls.target.z=T.MathUtils.clamp(controls.target.z,-55,55);controls.target.y=T.MathUtils.clamp(controls.target.y,0,20);controls.update();camera.position.y=Math.max(camera.position.y,8);const offset=mode==='overview'?(camera.aspect>1.2?.12:0):0;camera.setViewOffset(host.clientWidth,host.clientHeight,-host.clientWidth*offset,mode==='overview'&&camera.aspect<1.2?-host.clientHeight*.16:0,host.clientWidth,host.clientHeight);renderer.render(scene,camera);frames++;if(now-last>1000){fps=Math.round(frames*1000/(now-last));frames=0;last=now;}
 });pitch.select(selected,false);if(camera.aspect<1.3){camera.position.sub(controls.target).multiplyScalar(1.3/camera.aspect).add(controls.target);controls.update();}
 return {setPresentation(active){presentation=active;setMode('overview');},setLighting,setMode,select,zoom(factor){transition=null;camera.position.sub(controls.target).multiplyScalar(factor).add(controls.target);controls.update();},setRoof(show){roofEnabled=show;stadium.roof.visible=show&&mode==='overview';},diagnostics(){return {mode,selected,fps,camera:camera.position.toArray(),target:controls.target.toArray(),calls:renderer.info.render.calls,triangles:renderer.info.render.triangles,seats:stadium.seatCount,webgl:renderer.getContext().getParameter(renderer.getContext().VERSION)};},projectZone(id){const z=zoneDefinitions.find(z=>z.id===id),v=new T.Vector3(z.x,.1,z.z).project(camera);return {x:(v.x+1)/2*host.clientWidth,y:(1-v.y)/2*host.clientHeight};},dispose(){observer.disconnect();renderer.setAnimationLoop(null);controls.dispose();scene.traverse(o=>{o.geometry?.dispose();if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});environment.dispose();renderer.dispose();}};
}
