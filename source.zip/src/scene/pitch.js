import * as T from 'three';
import {zoneDefinitions} from '../data/demo.js';
export function buildPitch(){
 const group=new T.Group();
 const canvas=document.createElement('canvas');canvas.width=2048;canvas.height=1326;const c=canvas.getContext('2d');
 c.fillStyle='#39702f';c.fillRect(0,0,2048,1326);
 let seed=413;const rand=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
 for(let i=0;i<16;i++){c.fillStyle=i%2?'#467c39':'#3a6d31';c.fillRect(i*128,0,129,1326);}
 for(let i=0;i<240000;i++){const v=rand();c.fillStyle=v>.5?'rgba(163,181,78,.16)':'rgba(15,42,20,.18)';c.fillRect(rand()*2048,rand()*1326,1+rand()*2,2+rand()*4);}
 const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=8;
 const grass=new T.Mesh(new T.PlaneGeometry(105,68),new T.MeshStandardMaterial({map:tex,roughness:1,bumpMap:tex,bumpScale:.08}));grass.rotation.x=-Math.PI/2;grass.receiveShadow=true;group.add(grass);
 const surround=new T.Mesh(new T.PlaneGeometry(122,82),new T.MeshStandardMaterial({color:0x294c31,roughness:1}));surround.rotation.x=-Math.PI/2;surround.position.y=-.25;group.add(surround);
 const white=new T.LineBasicMaterial({color:0xe6ead8});
 const path=(points,mat=white)=>{const l=new T.Line(new T.BufferGeometry().setFromPoints(points.map(([x,z])=>new T.Vector3(x,.065,z))),mat);group.add(l);return l;};
 const rect=(x,z,w,d)=>path([[x,z],[x+w,z],[x+w,z+d],[x,z+d],[x,z]]);
 rect(-52.5,-34,105,68);path([[0,-34],[0,34]]);
 path(Array.from({length:97},(_,i)=>[Math.cos(i/96*Math.PI*2)*9.15,Math.sin(i/96*Math.PI*2)*9.15]));
 for(const s of [-1,1]){
  rect(s<0?-52.5:36,-20.16,16.5,40.32);rect(s<0?-52.5:47,-9.16,5.5,18.32);
  const spot=new T.Mesh(new T.CircleGeometry(.16,12),new T.MeshBasicMaterial({color:0xffffff}));spot.rotation.x=-Math.PI/2;spot.position.set(s*41.5,.07,0);group.add(spot);
  const arc=[];for(let i=0;i<=32;i++){const a=-.925+i/32*1.85;arc.push([s*(41.5-9.15*Math.cos(a)),9.15*Math.sin(a)]);}path(arc);
  const goalPos=[];const line=(a,b)=>goalPos.push(...a,...b);
  for(const z of [-3.66,3.66]){line([s*52.5,0,z],[s*52.5,2.44,z]);line([s*52.5,2.44,z],[s*54.5,2.44,z]);line([s*54.5,2.44,z],[s*54.5,0,z]);}
  line([s*52.5,2.44,-3.66],[s*52.5,2.44,3.66]);line([s*54.5,2.44,-3.66],[s*54.5,2.44,3.66]);
  for(let z=-3.66;z<3.67;z+=.35)line([s*54.5,0,z],[s*54.5,2.44,z]);
  for(let y=0;y<2.45;y+=.35)line([s*54.5,y,-3.66],[s*54.5,y,3.66]);
  group.add(new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(goalPos,3)),white));
 }
 const centre=new T.Mesh(new T.CircleGeometry(.18,16),new T.MeshBasicMaterial({color:0xe6ead8}));centre.rotation.x=-Math.PI/2;centre.position.y=.07;group.add(centre);
 for(const x of [-52.5,52.5])for(const z of [-34,34]){path(Array.from({length:17},(_,i)=>{const a=i/16*Math.PI/2;return [x-Math.sign(x)*Math.cos(a),z-Math.sign(z)*Math.sin(a)];}));}
 const hitTargets=[],outlines=[],labels=[];
 for(const z of zoneDefinitions){
  const target=new T.Mesh(new T.PlaneGeometry(z.width,z.depth),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));target.rotation.x=-Math.PI/2;target.position.set(z.x,.11,z.z);target.userData.zone=z.id;group.add(target);hitTargets.push(target);
  const labelCanvas=document.createElement('canvas');labelCanvas.width=128;labelCanvas.height=64;const lc=labelCanvas.getContext('2d');lc.fillStyle='#112820dd';lc.beginPath();lc.roundRect(2,2,124,60,12);lc.fill();lc.strokeStyle='#99c6a8';lc.lineWidth=2;lc.stroke();lc.fillStyle='#e5f3e8';lc.font='bold 31px sans-serif';lc.textAlign='center';lc.fillText(z.id,64,43);const labelTex=new T.CanvasTexture(labelCanvas);labelTex.colorSpace=T.SRGBColorSpace;const label=new T.Sprite(new T.SpriteMaterial({map:labelTex,depthTest:false,transparent:true}));label.position.set(z.x-z.width/2+4,1,z.z-z.depth/2+3);label.scale.set(5,2.5,1);label.renderOrder=5;group.add(label);labels.push(label);
  const outline=rect(z.x-z.width/2+.2,z.z-z.depth/2+.2,z.width-.4,z.depth-.4);outline.material=new T.LineBasicMaterial({color:0x7bdac2,transparent:true,opacity:.4});outline.position.y=.07;outlines.push(outline);
 }
 return {group,hitTargets,select(id,visible){labels.forEach(l=>l.visible=visible);outlines.forEach((o,i)=>{o.visible=visible;o.material.color.set(zoneDefinitions[i].id===id?0xc4ffe4:0x7bdac2);o.material.opacity=zoneDefinitions[i].id===id?1:.28;});},grass};
}
