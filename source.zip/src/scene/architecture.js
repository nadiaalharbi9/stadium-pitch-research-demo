import * as T from 'three';
// Original procedural detail; dimensions are artistic study assumptions.
export function beamInstances(pairs,radius,material){
 const mesh=new T.InstancedMesh(new T.CylinderGeometry(radius,radius,1,6),material,pairs.length),o=new T.Object3D(),up=new T.Vector3(0,1,0);
 pairs.forEach(([a,b],i)=>{o.position.copy(a).add(b).multiplyScalar(.5);const d=b.clone().sub(a);o.quaternion.setFromUnitVectors(up,d.clone().normalize());o.scale.set(1,d.length(),1);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);});return mesh;
}
export function makePlaza(){
 const group=new T.Group(),stone=new T.MeshStandardMaterial({color:0x40494b,roughness:.95});
 const paving=new T.Mesh(new T.CylinderGeometry(148,148,1,160),stone);paving.scale.z=.86;paving.position.y=-3;group.add(paving);
 const seams=[];for(const radius of [123,131,139,147])for(let i=0;i<160;i++){const a=i/160*Math.PI*2,b=(i+1)/160*Math.PI*2;seams.push(radius*Math.cos(a),-2.48,radius*.86*Math.sin(a),radius*Math.cos(b),-2.48,radius*.86*Math.sin(b));}
 for(let i=0;i<80;i++){const a=i/80*Math.PI*2;seams.push(120*Math.cos(a),-2.47,120*.86*Math.sin(a),148*Math.cos(a),-2.47,148*.86*Math.sin(a));}
 group.add(new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(seams,3)),new T.LineBasicMaterial({color:0x58615f,transparent:true,opacity:.45})));
 const lights=[],posts=[],v=(r,a,y)=>new T.Vector3(r*Math.cos(a),y,r*.86*Math.sin(a));
 for(let i=0;i<48;i++){const a=i/48*Math.PI*2;posts.push([v(141,a,-2.4),v(141,a,-.1)]);lights.push([v(141,a,-.1),v(141,a,.2)]);}
 group.add(beamInstances(posts,.15,new T.MeshStandardMaterial({color:0x1a252b,roughness:.7})),beamInstances(lights,.22,new T.MeshBasicMaterial({color:0xffd9a0})));
 return group;
}
