export const requiresReview = z => z.condition !== 'No visible issue' || ['Moderate','Heavy','Unknown'].includes(z.wear) || z.shade === 'High' || ['Reinspect','Specialist review'].includes(z.status);
// Scheduling illustration only: count scheduled rounds strictly before kickoff.
export function compareScenarios(zones,hours) {
 const h=Number(hours); if(!Number.isFinite(h)||h<1||h>336) throw new RangeError('Fixture horizon must be 1–336 hours');
 const flagged=zones.filter(requiresReview).map(z=>z.id);
 const rounds=interval=>Math.max(0,Math.ceil(h/interval)-1);
 return {hours:h,flagged,routine:{interval:24,rounds:rounds(24),visits:rounds(24)*flagged.length},enhanced:{interval:12,rounds:rounds(12),visits:rounds(12)*flagged.length}};
}
export function handover(zones,hours) {
 const c=compareScenarios(zones,hours);
 return `AL JAWHARA TURF TWIN — ILLUSTRATIVE HANDOVER\nFixture horizon: ${c.hours} hours (user assumption).\nReinspection queue: ${c.flagged.join(', ')||'None flagged'}.\nRoutine: ${c.routine.rounds} rounds / ${c.routine.visits} zone visits. Enhanced: ${c.enhanced.rounds} rounds / ${c.enhanced.visits} zone visits.\nAssumptions: first round after 24h or 12h; only rounds strictly before kickoff; every flagged zone visited each round; no staff-capacity model.\n${zones.filter(requiresReview).map(z=>`${z.id}: ${z.condition}; wear ${z.wear}; shade ${z.shade}; ${z.status}. ${z.notes}`).join('\n')}\nNext step: physically reinspect flagged areas; seek qualified agronomic assessment for concerns. A completed follow-up does not remove a recorded concern.\nSynthetic examples / local manual entries. No sensors connected. No recovery forecast, safety clearance or FIFA certification.`;
}
