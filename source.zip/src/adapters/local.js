import {freshDemo,CONDITIONS,WEAR,SHADES,STATUSES} from '../data/demo.js';
export const STORAGE_KEY='jawhara-turf-twin-v2';
export function validateRecords(raw) {
 if(!raw||raw.version!==2||!Array.isArray(raw.zones)||raw.zones.length!==9) return freshDemo();
 const ids=new Set(raw.zones.map(z=>z?.id)); if(ids.size!==9) return freshDemo();
 return freshDemo().map(base=>{const z=raw.zones.find(v=>v?.id===base.id);if(!z)return base;
 return {...base,condition:CONDITIONS.includes(z.condition)?z.condition:base.condition,wear:WEAR.includes(z.wear)?z.wear:base.wear,shade:SHADES.includes(z.shade)?z.shade:base.shade,status:STATUSES.includes(z.status)?z.status:base.status,notes:typeof z.notes==='string'?z.notes.slice(0,500):base.notes,provenance:z.provenance==='manual-local'?'manual-local':'synthetic-demo',updatedAt:typeof z.updatedAt==='string'&&Number.isFinite(Date.parse(z.updatedAt))?z.updatedAt:null};});
}
export function loadRecords(storage){try{return validateRecords(JSON.parse(storage.getItem(STORAGE_KEY)));}catch{return freshDemo();}}
export function saveRecords(storage,zones){try{storage.setItem(STORAGE_KEY,JSON.stringify({version:2,zones}));return true;}catch{return false;}}
// Future adapters must provide timestamp, units, calibration, provenance and CRS.
// No sensor endpoints, measurements or georeferencing are simulated here.
