// Synthetic examples only. Coordinates use a local metre-based frame, not a survey.
export const PITCH = Object.freeze({length:105,width:68,crs:'LOCAL_DEMO_METRES',origin:'pitch centre',xAxis:'length',zAxis:'width'});
export const CONDITIONS = ['No visible issue','Visible wear','Specialist review','Not inspected'];
export const WEAR = ['None recorded','Light','Moderate','Heavy','Unknown'];
export const SHADES = ['Low','Moderate','High','Unknown'];
export const STATUSES = ['Monitor','Reinspect','Specialist review','Follow-up completed'];
export const zoneDefinitions = Array.from({length:9},(_,i)=>({id:`${'ABC'[Math.floor(i/3)]}${i%3+1}`,x:(i%3-1)*35,z:(Math.floor(i/3)-1)*68/3,width:35,depth:68/3}));
export const freshDemo = () => zoneDefinitions.map((z,i)=>({...z,condition:i===4?'Specialist review':[2,7].includes(i)?'Visible wear':'No visible issue',wear:i===4?'Heavy':[2,7].includes(i)?'Moderate':'None recorded',shade:[2,4].includes(i)?'High':'Low',status:i===4?'Specialist review':[2,7].includes(i)?'Reinspect':'Monitor',notes:i===4?'Synthetic example: concentrated wear near the centre. Arrange a physical assessment.':[2,7].includes(i)?'Synthetic example: visible thinning. Reinspect after maintenance.':'Synthetic example: no visible issue recorded.',provenance:'synthetic-demo',updatedAt:null}));
