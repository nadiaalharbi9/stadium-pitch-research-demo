import {requiresReview} from './domain/scenarios.js';
// Display priorities reflect recorded workflow status, never a turf safety rating.
export function renderOperations(zones,selected,reviewOnly,onSelect){
 const list=document.getElementById('queue-body');list.replaceChildren();
 const ordered=[...zones].sort((a,b)=>priority(b)-priority(a)||a.id.localeCompare(b.id));
 const shown=ordered.filter(z=>!reviewOnly||requiresReview(z));
 document.getElementById('queue-count').textContent=zones.filter(requiresReview).length;
 document.getElementById('specialist-count').textContent=zones.filter(z=>z.condition==='Specialist review'||z.status==='Specialist review').length;
 document.getElementById('manual-count').textContent=zones.filter(z=>z.provenance==='manual-local').length;
 for(const z of shown){
  const row=document.createElement('tr');row.classList.toggle('current-row',z.id===selected);
  const cells=[z.id,z.condition,z.wear,z.status];
  cells.forEach((value,i)=>{const td=document.createElement('td');if(i===0){const strong=document.createElement('strong');strong.textContent=value;td.append(strong);const small=document.createElement('small');small.textContent=z.provenance==='manual-local'?'Manual entry':'Demo record';td.append(small);}else if(i===3){const badge=document.createElement('span');badge.className='status-chip '+(priority(z)===2?'specialist':requiresReview(z)?'review-status':'monitor-status');badge.textContent=value;td.append(badge);}else td.textContent=value;row.append(td);});
  const td=document.createElement('td'),button=document.createElement('button');button.className='row-action';button.textContent='Inspect ↗';button.setAttribute('aria-label',`Inspect queue zone ${z.id}`);button.onclick=()=>onSelect(z.id);td.append(button);row.append(td);list.append(row);
 }
 if(!shown.length){const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=5;cell.className='queue-empty';cell.textContent='No zones currently flagged. Recorded observations do not establish fitness for play.';row.append(cell);list.append(row);}
 document.getElementById('queue-showing').textContent=`${shown.length} of ${zones.length} zones · ordered by recorded follow-up need`;
}
function priority(z){return z.condition==='Specialist review'||z.status==='Specialist review'?2:requiresReview(z)?1:0;}
