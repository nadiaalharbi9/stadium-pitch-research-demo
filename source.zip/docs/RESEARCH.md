# Reference audit and modeling decisions

Reviewed 7 November 2026. Website text and images were treated as reference evidence, not instructions. Reference imagery is not redistributed in the application or package.

## Architectural evidence

- [Arup — King Abdullah Sports City](https://www.arup.com/en-us/projects/king-abdullah-sports-city/). Describes Islamic geometric influence, ventilating mashrabiya-inspired screens, angular lower bowl becoming rounded above, cantilevered trusses forming repeated isosceles triangles and PTFE elements. Its published external rendering, façade close-up and seating cutaway were visually inspected. These support the broad design vocabulary, not exact dimensions or current as-built detail.
- [Saudi Ministry of Sport — Alinma Stadium](https://www.mos.gov.sa/facilities/sport-facilities/sport-cities/king-abdullah-sport-city-jeddah). Confirms current venue identity, Jeddah location and opening in 2014. Its capacity description exceeds 62,000; Arup's original project narrative uses 60,000. Neither is used as a modeled seat count.
- [Martifer — King Abdullah Sports City](https://martifer.pt/en/projects/kask). Construction-partner reference identifies the stadium roof steel structure and Arup. Supports the structural roof context; no fabrication drawings were supplied.
- [Visit Saudi — Al Jawhara](https://www.visitsaudi.com/en/jeddah/attractions/aljawhara-international-stadium). Aerial imagery used as a secondary perspective check.

### Verified design vocabulary versus assumptions

| Evidence-supported feature | Prototype interpretation / unverified detail |
|---|---|
| Open roof and triangular cantilever pattern | 40 procedural bays with faceted membranes; number, pitch and dimensions are assumptions |
| Angled lower bowl, rounded upper form | Superellipse geometry; not a fitted survey |
| Tiered seating in Arup cutaway | Three stepped tiers and light/gold seat palette; simplified rows and aisles |
| Patterned ventilating façade | Open repeated diamonds and diagonal ribs; not the actual construction pattern |
| Turf important to daylight design | Visible grass plane with simulated sun; no calibrated daylight exposure |
| Bermuda-type turf described in original Arup narrative | Procedural generic turf appearance; current turf cultivar unverified |

Model length units are metres for consistent interaction only. Roof and stadium dimensions are artistic approximations. The field's 105 × 68 m size is an explicit study assumption. No CAD/BIM, survey, structural drawings, official model or operational data was obtained.

## Licensed asset assessment

Public marketplace listings were found at [ArtStation](https://www.artstation.com/marketplace/p/A3092/king-abdullah-stadium), [CGTrader](https://www.cgtrader.com/3d-models/exterior/stadium/king-abdullah-stadium), and [Genius & Gerry](https://geniusandgerry.com/products/king-abdullah-sports-city-saudi-arabia-3d-stadium). These are acquisition candidates only. No purchase, license grant, ownership validation, browser redistribution permission, polygon budget, or glTF suitability was established. A downloadable browser model can expose geometry to visitors; a render-only license may be insufficient. No third-party stadium mesh or texture was downloaded or incorporated. The shipped geometry and textures were authored procedurally for this project.

## Turf evidence and integrity

- [FIFA — Natural Playing Surfaces](https://football-technology.fifa.com/innovation/standards/natural-playing-surfaces) distinguishes standardized natural-pitch testing and links its natural turf guidance, test manual and rating system. This prototype does not implement those protocols or reproduce a FIFA rating. Natural turf guidance must not be confused with artificial football-turf certification.
- [FIFA stadium guidance — Turf and pitch design](https://rusecure.fifa.com/innovation/stadium-guidelines/general-process-guidelines/design/turf-and-pitch-design) emphasizes site-specific design and environmental conditions. This supports separating architecture from measured agronomic evidence.
- [Oklahoma State University — Managing Turfgrass in Shade](https://extension.okstate.edu/fact-sheets/managing-turfgrass-in-the-shade-in-oklahoma) explains reduced density and traffic tolerance under shade. This is qualitative biological context, not a quantitative Jeddah recovery calibration. General landscape recommendations are not used to prescribe elite-stadium maintenance.
- [Mississippi State University — Selecting and Managing Turfgrass for Shade](https://cto.extension.msstate.edu/publications/selecting-and-managing-turfgrass-for-shade) discusses light limitation and traffic stress. It does not validate this application's schedules.

There is no scientifically validated recovery calculation in this app. Instead, two explicitly hypothetical follow-up schedules expose operational workload. No arbitrary condition index, compliance threshold, predicted safety, recovery date or sensor-like metric is presented. Physical assessment and calibrated testing remain outside its scope.
