# GitHub Pages deployment — only after owner approval

No deployment or push was performed. The existing public demo was not replaced. The connected GitHub account was checked using repository metadata and has `pull: true`, `push: false`. This handoff therefore includes local source, a Git bundle, patch, and a built static ZIP.

## Restore the development branch

Preferred: clone the supplied Git bundle, which preserves history and the development branch. Alternatively extract the source ZIP into a new dedicated directory. Do not overwrite an existing working tree with uncommitted edits.

```sh
git clone al-jawhara-turf-twin.bundle jawhara-turf-twin
cd jawhara-turf-twin
git switch feature/jawhara-turf-twin
npm ci
npm test
npm run build
npm run preview
```

For an authorized repository checkout, the supplied patch can instead be applied on a new branch based on the recorded baseline. Review and test before merging.

## Publish the reviewed build

After explicit owner approval, push the feature branch with an account that has write permission. Review the diff and choose the GitHub Pages publishing strategy. Two safe options:

1. **GitHub Actions**: add the example workflow from `docs/pages-workflow.yml.example` at `.github/workflows/pages.yml`, set Pages source to GitHub Actions, and run its manual dispatch on the approved branch. It builds `dist/` and publishes only that artifact. The example is deliberately inactive in this delivery.
2. **Static branch**: on a separately prepared `gh-pages` branch, put the *contents* of `dist/` at the publishing root and configure Pages to that branch/root. Do not replace `main` with build output and do not accidentally remove source history.

`base: './'` makes generated asset URLs relative, compatible with `/stadium-pitch-research-demo/`. There is no SPA path routing requiring a 404 rewrite. Always serve the build over HTTP.

After publication, verify the actual Pages URL and loaded asset responses, WebGL rendering, all camera modes, a zone edit/reload, and handover export. Check browser console errors on the public build. Only then describe the replacement as live. The URL supplied by the user identifies the existing demo; it is not evidence that this version is deployed.

Workflow structure reviewed against [GitHub’s custom Pages workflow documentation](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages). The inactive template itself has not been executed in GitHub Actions.
