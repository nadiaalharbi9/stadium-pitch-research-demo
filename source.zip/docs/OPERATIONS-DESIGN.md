# Operations interface design

The page now presents an operational workspace rather than a standalone architectural showcase. The original 3D model, synthetic observation boundaries, persistence schema and schedule calculation remain intact.

## Information order

1. Header identifies the workspace and demo environment, with study notes and presentation mode.
2. Page heading makes the two main actions explicit: begin an inspection or export a handover.
3. Four compact summaries show recorded zones, reinspection flags, specialist-review records and the assumed fixture horizon. None is a safety or readiness score.
4. Spatial workspace and zone notebook remain adjacent on desktop. Camera controls sit within the scene; inspection inputs have their own quieter panel.
5. Follow-up queue exposes recorded concerns in a scannable table. Specialist-review records sort first, then other flagged records. Filters switch between flagged and all nine zones. Inspect actions link back to the corresponding scene and notebook.
6. Fixture planning exposes the transparent routine/enhanced schedule assumptions; the handover follows immediately below.

Dark slate surfaces, restrained green actions, amber follow-up indicators, consistent borders, clearer typography and grouped controls form the visual system. Status labels supplement color. No invented team names, assignments, live timestamps, weather, sensor metrics or readiness percentages are shown.

On narrow screens the scene, notebook, follow-up queue and planner stack in that order; the decorative navigation rail disappears. Presentation mode temporarily hides the operational panels for an interview walkthrough.

## Design references and boundaries

[FIFA facility-management guidance](https://ipt.fifa.com/innovation/stadium-guidelines/general-process-guidelines/operations/facility-management) identifies maintenance, inspection, coordination and daily operations as relevant stadium functions. This informs the workflow hierarchy, not a claim of operational compliance. [SGL](https://sglsystem.com/) provides sector context for specialist turf management and monitoring; no proprietary dashboard, branding or asset is copied. This app still has no live monitoring connection.

## Verification

The six domain tests remain unchanged. The full Chrome interaction suite covers camera operation, all-zone picking, saved records and export. A dedicated operations suite covers queue order/filtering, row-to-scene navigation, start inspection, manual-entry counts, fixture summary synchronization, header export, presentation visibility and mobile overflow. Actual screenshots are captured at 1440px and 390px widths.

## Visual quality refinement

The user clarified that FIFA and PlayStation are references for concept strength, typography, precision and presentation quality, not requests to copy branding. The official [FIFA Training Centre](https://www.fifatrainingcentre.com/en/) was visually reviewed for hierarchy, prominent typography and restrained actions. The final independent interface uses a navy/graphite system, blue primary actions, consistent original SVG line icons, and self-hosted Manrope Variable typography. Green/amber states remain reserved for the turf workflow. No FIFA or PlayStation marks, proprietary fonts, screenshots or brand assets are included. Manrope is bundled from Fontsource under its included open-font license.
