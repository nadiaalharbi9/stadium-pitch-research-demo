# Immersive stadium operations prototype

This iteration replaces the visible dashboard shell with a full-viewport WebGL stage. It remains an independent Al Jawhara-inspired architectural study, not a surveyed stadium model or a live digital twin.

## Experience

- **Explore Stadium:** editorial opening, free orbit, right-drag pan, wheel/button zoom, reset, roof visibility and illustrative lighting. HUD text can be hidden. Camera composition leaves room for the introduction.
- **Inspect Pitch:** roof removed for visibility, smooth camera transition, top-down view, nine raycast-selectable zones, precise focus targets. A collapsible notebook sits beside the stage on desktop and below it on mobile.
- **Operations Review:** a dedicated scrollable review surface, with the stadium retained as background context. Observation counts, review queue, fixture assumptions and text handover remain derived from local records. Queue actions return to the selected turf zone.

The scene occupies the viewport rather than a dashboard card. Inspecting a zone never overlays an opaque heatmap on the turf. Fullscreen here means a viewport-filling layout, not forced browser fullscreen.

## Design decisions

Graphite and deep navy surfaces, translucent panels, restrained ice-blue controls, locally bundled Manrope typography, and consistent spacing. Observation warnings retain amber; they are not readiness or safety ratings. Motion lasts approximately 1.65 seconds with a quintic ease; reduced-motion preferences skip the transition. User camera gestures cancel automated motion.

Visual changes include a closer oblique opening, more organized seating color blocks, shaded architectural context, revised mowing bands, centre spot and corner arcs. The existing procedural triangular roof, facade lattice, stepped seating, and instanced seat geometry are retained. Geometry and lighting remain illustrative.

## Architecture

- `src/immersive.js`: mode shell and panel coordination, separate from data.
- `src/immersive.css`: viewport/HUD and responsive presentation.
- `src/main.js`: observation form, state orchestration and export.
- `src/scene/viewer.js`: rendering, controls, camera interpolation and raycasting.
- `src/scene/stadium.js`, `architecture.js`, `pitch.js`: procedural scene assets.
- Existing `data`, `domain` and `adapters` modules retain synthetic examples, transparent scenario arithmetic and local persistence.
- `tests/immersive.mjs`: current Chrome regression suite. Historical dashboard suites describe previous UI layouts and are not the current mode-navigation suite.

## Limits and pre-deployment step

No official CAD/BIM was supplied. Seat count, dimensions beyond the study pitch, roof facets, materials and lighting are approximations. Evening lights are artistic, not a lux calculation. The surface texture is procedural, not measured grass imagery. There is no physical collision model, validated agronomic forecast, safety certification, sensor connection, multi-user storage or backend. The local coordinate frame is not georeferenced. Mobile prioritizes a usable notebook over cinematic desktop composition.

Before publishing: review the three modes on the intended interview laptop at its actual resolution, confirm the opening composition and notebook readability, then explicitly approve replacing the GitHub Pages version. Deployment instructions remain in README. No public deployment is part of this iteration.
