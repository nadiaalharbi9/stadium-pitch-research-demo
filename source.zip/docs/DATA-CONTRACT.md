# Future data contract

This document describes proposed boundaries, not implemented integrations.

The current `ZoneDefinition` is `{id, x, z, width, depth}` in `LOCAL_DEMO_METRES`, origin at field centre. Geometry coordinates are authoritative within the demo and never restored from editable browser storage. User data is a record keyed by ID with `condition`, `wear`, `shade`, `status`, `notes`, `provenance`, `updatedAt`. Stored snapshots have `version: 2`. Unknown enum values, duplicate IDs and malformed data are rejected or sanitized.

Future measured observations should be append-only records with:

- `observationId`, `zoneId`, `observedAt`, `receivedAt`, `sourceType` and `sourceId`.
- `metric`, `value`, `unit`, `uncertainty`, `qualityFlags`, `calibrationReference`.
- `position`, `crs`, `verticalDatum` where spatial measurements are involved.
- `license` and evidence/source references for imported spatial imagery.

Possible adapters: licensed stadium geometry, surveyed zone transforms, soil moisture, temperature, photosynthetically relevant light, multispectral/NDVI observations, maintenance events and historical time series. No empty fabricated readings should be shown as zeros. Missing, stale, invalid and synthetic measurements require distinct states. Derived conclusions must retain provenance and identify model validation status. Raw NDVI alone is not a safety decision.

A GLB geometry adapter should return a scene group and bounds, without owning inspection state. A georeferencing adapter must supply a documented local-to-world transform; the current axes are not geographic north. A remote data adapter would sit behind domain validation and must not be called by rendering components. Secrets belong on an authenticated server, never in the static Pages bundle.
