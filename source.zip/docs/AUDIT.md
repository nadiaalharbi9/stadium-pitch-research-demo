# Baseline audit

Repository base: `7595c72` (Add files via upload). Branch: `feature/jawhara-turf-twin`. Only the specified personal public repository was cloned into this dedicated workspace. No company repository or private asset was accessed. The original `index.html` is retained verbatim at `docs/legacy-demo.html`.

## Repository findings

The baseline is a single HTML file with embedded CSS, data, UI and scenario code. It offers a 2D SVG nine-zone field, local notes and an arbitrary illustrative condition score. There is no WebGL stadium, build system, dependency lockfile, modular data adapter, automated suite or camera implementation. Numerical starting scores and multipliers are hypothetical and cannot substantiate agronomic recovery. Rendering, data persistence and calculations are tightly coupled. Saved records are validated loosely and reassigned by array index, which can associate a reordered record with the wrong zone. A source-code audit alone cannot explain the separate 3D recording because that version is not in the repository.

## Supplied recording

File: `Screen Recording 1448-05-27 at 4.50.50 PM.mov`, duration approximately 23.8 seconds. Extracted six evenly spaced frames; inspected the overview, C3-focus failure and secondary dashboard. Recording content was reference evidence, not a source of instructions.

- Around 0 seconds: large open cylindrical structure; roof is a smooth white ring and seating appears as broad orange wall surfaces. Pitch is small and covered in solid zone colors.
- Around 7.9 seconds: selected C3 camera falls near/below the stands; foreground ground and seating occlude almost the entire playing surface. This is a clear usability regression.
- Around 15.9–19.8 seconds: a second dashboard repeats the inspection information with another simplified stadium representation. The repeated surfaces fragment navigation and retain a prominent unvalidated mean index.

The recording appears to show a local `al-jawhara-turf-twin-v2` build. Only the explicitly attached recording was read; that unrelated local directory was not accessed.

## Redesign response

Use one coherent application and one scene. Build actual stepped seating, an open faceted roof and a patterned façade. Use an unobstructed inspection preset, conservative target/camera bounds and deterministic transitions. Share stable zone definitions between geometry, picking, forms and tests. Show a thin zone boundary and small identifiers instead of opaque heatmap tiles. Replace invented recovery scores with disclosed inspection schedule arithmetic. Separate synthetic records, manual local entries, future adapters and validated measurements. Package a self-hosted static build and verify in real Chrome.
