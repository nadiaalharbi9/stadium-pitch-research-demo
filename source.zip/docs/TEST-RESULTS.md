# Verification record

Date: 7 November 2026. Local production build served over HTTP. Existing public site untouched.

## Automated

- `npm run build`: passed with Vite 6.4.5; static HTML/CSS/JS generated with relative asset paths.
- `npm test`: 6/6 passed. Covers kickoff boundary arithmetic, invalid horizon inputs, unresolved-concern retention, ID-based persistence, invalid stored data, storage denial and handover boundaries.
- `TEST_URL=http://127.0.0.1:4173 npm run test:browser`: 15/15 checks passed in installed Google Chrome 157.0.8103.39, headless, isolated browser profile.
- Core browser checks: real WebGL2 rendering, actual pointer raycasts for all nine zones, correct camera target coordinates, positive camera height, persistence over reload, safe plain-text notes, draft preservation, scenario updates and downloaded handover, mouse orbit and right-drag pan, zoom/reset, keyboard selection, research dialog, responsive overflow checks, normal console/runtime errors, denied local storage and unavailable WebGL.
- Additional focused checks and short demonstration: `node tests/failure-and-demo.mjs` checks the roof toggle, normal demonstration runtime errors, actual forced WebGL context loss, initial graphics failure and notebook-only fallback labels.
- `npm audit`: 0 known reported vulnerabilities at audit time. Vite was upgraded from 6.4.1 to 6.4.5 after its initial audit identified development-server advisories.
- `git diff --check`: passed. Focused credential-pattern scan of authored source, docs and public assets found no matches. No credentials were added or printed; this scan is not a universal security certification.

## Desktop performance

Production Chrome sample at 1440 × 1100, DPR 1: five one-second samples were 60, 59, 60, 60, 60 fps while video capture was active. Initial sample during loading was 41 fps. This is a small local observation, not a benchmark across machines. Approximately 214,936 rendered triangles, 35 overview draw calls and 15,206 instanced seats were reported. Textured zone labels add draws in inspection mode. No mobile GPU benchmark or thermal test was performed.

## Manual visual inspection

Native desktop Chrome was opened using the computer-use browser interface. Overview, pitch transition, top-down and C3 focus were exercised and inspected. C3 now looks down onto the correct playing surface rather than beneath the seating. Actual screenshot outputs were inspected for overview, inspection, top-down, C3, 390px mobile layout and graphics fallback. Automated screenshots also cover 1024px and 1280px widths. No horizontal overflow was detected at those sizes. The application is designed primarily for desktop; on a phone, the notebook stacks below the scene and planner.

## Issues found and resolved

- Missing favicon produced a 404 console error in the first end-to-end run. Added a bundled SVG icon and reran the suite successfully.
- Scene-title text had low contrast against bright seating in inspection mode. Added a restrained translucent backing.
- Inspection mode initially retained a confusing Roof on button. It now shows disabled Roof hidden while the roof is intentionally removed.
- Fallback selection originally described a visible highlight despite graphics being unavailable. It now identifies a notebook-only view; camera controls remain disabled.

## Remaining limits / defects

No full camera collision solver: unusual manual orbit/zoom positions can intersect stadium geometry. Automatic focus paths for all zones were verified. Roof transition is a deliberate visibility switch, not a physically animated roof. The procedural façade, seating blocks and light/gold colors remain stylized. Small labels are a visual aid; accessible zone buttons are the reliable keyboard alternative. No real-world observations or measurement validation was undertaken. No cross-browser, screen-reader certification, sustained mobile performance or live GitHub Pages deployment test was performed. Context recovery requires reload. Fixture horizon resets to 72 hours on reload; observation records persist.

Machine-readable evidence: `browser-results.json` and `additional-results.json` in the delivery evidence folder. Screenshots and recording show the running application, not generated mockups.

## Architectural refinement verification

After chair backs, solid façade members, truss detailing and studio material environment were added, the full 15-check Chrome suite passed again with zero normal runtime/console errors. The updated overview reports 498,528 triangles, 43 draw calls and 15,206 seat instances. Five steady FPS samples were all 60; initial sample was 51. The test environment and limitations above still apply. A separate five-check presentation suite verifies the expanded scene, lighting toggle, notebook restoration, camera reset and C3 focus after leaving presentation. Presentation screenshots are new evidence. The final presentation framing and light-intensity adjustments were verified by this focused suite; no changes were made to persistence or schedule calculations.

Final visual QA also identified depth-buffer interference between the grass and nearly coplanar surround at distant camera views. The camera near plane and surface separation were adjusted; the presentation test was rerun to capture the corrected geometry.

## Operations interface redesign

The redesigned operational layout passed all 15 existing Chrome checks and the six domain tests. The dedicated operations suite verifies 10 supervisor workflows, including filtered/sorted follow-up rows, direct focus from a row, entry counts, fixture horizon summary, header export, presentation restoration and mobile overflow. After the typography and navy/blue visual refinement, the operations suite is rerun against the final build. Font assets are self-hosted; no external font service is contacted. A mobile grid min-width overflow found after increasing typography was corrected by constraining card and table containers. The final build and dependency audit pass. The first broad-suite loading sample under concurrent browser work was only 3 FPS; its later five steady samples were 60, 59, 60, 60, 60. This is not a startup performance guarantee.

## Immersive simulator — 7 November 2026

Current suite: `npm run test:browser` / `tests/immersive.mjs`, installed desktop Chrome through Playwright, isolated browser profile, local preview on port 4173.

- Production build succeeded; six domain tests passed.
- Seventeen Chrome checks passed: viewport-filling WebGL2 render; orbit; pan; zoom/reset; roof/lighting controls; inspect transition; all nine real canvas raycasts and exact zone camera targets; persistence and safe notes; review/autosave/filtering; fixture/export; queue-to-zone transition; collapse/reopen notebook; keyboard selection; HUD/dialog; responsive 1280 and 390 layouts; no console/runtime errors; usable notebook when WebGL is unavailable.
- Three settled frame-rate samples: 60, 60, 60 FPS on this machine. This is not a cross-device benchmark or startup-time guarantee.
- Visual inspection covered explore, inspect, focus, operations review and mobile screenshots. Visible Chrome was also used to enter inspection and the top-down view.
- A fallback-path defect (disabled camera control also preventing access to the notebook) was found and fixed before the final passing run.
- `git diff --check` passed.
- Screenshots and machine-readable results are in the delivery package. Demo recording is a real browser capture with synthetic sample records.
- Earlier dashboard test results above are historical; the new suite is the current UI regression entry point.
